
const Aux1=(props) => props.children;
export default Aux1;

