



<!DOCTYPE html>
<html>
<head>
<title>login page</title>
</head>
<body>


<font color="red">WELCOME </font>
<?php
echo"heloo this is session some_name".$_SESSION['username1']."<br>";
?>

<font color="red">WELCOME </font>
<?php
echo"heloo this is session some_name".$_SESSION['some_name']."<br>";
?>
<br><br>

<font color="red">WELCOME </font><?php echo $username12; ?>
<br><br>

<font color="red">WELCOME </font>
<?php echo $this->session->userdata('username1'); ?>
<br>
<a href="http://localhost/codeigniter_urbanfit/index.php/dinesh_c/logout">loguot</a>

</body>
</html>