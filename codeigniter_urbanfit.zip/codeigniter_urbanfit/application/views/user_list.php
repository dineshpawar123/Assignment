<!Doctype html>
<html>
	<body>
		<table>
			
			<table border='1' cellspacing='2'cellpading='4'>
			<?php echo $as; ?>
			<?php foreach($user as $v) { ?>
		
			<tr>
				<td>
					<?php echo  $v['firstname']?>
				</td>
				<td>
					<?php  echo $v['lastname']?>
				</td> 
			</tr>	

		    <?php } ?>

		</table>
	</body>
</html>