
<!DOCTYPE html>
<html>
<head>
<title>crud application</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'?>">


</head>	

<body>
	<div class="navbar navbar-dark bg-dark">
		<div class="container">
			<a href="#" class="navbar-brand">  View  Users </a>
		</div>
	</div>

	<div class="container" style="padding-top :10px;">
		<div class="row">
			<div>
					<div class="col-md-12">
						 <?php
						$success=$this->session->userdata('success');
						if($success !="")
						{
						?>
						<div  class="alert alert-success"><?php echo $success;?></div>

						<?php
						 }
						?>

						<?php
						$failure=$this->session->userdata('failure');
						if($failure !="")
						{
						?>

						<div  class="alert alert-failure"><?php echo $failure;?></div>

						<?php
						 }
						?>
					</div>	
			</div>
		</div>	
			<div class="col-md-8">
					<div class="row">
						<div class="col-6"><h3>Views users</h3></div>

						<div class="col-6 text-right">
							<a href="<?php echo base_url().'index.php/user/create/'?>" class="btn btn-primary">+ Add New Nutritionist</a>
							
						</div>
					</div>
			</div>
			<hr>
		</div>			
	</div>

	<div class="row">	
		<div class="col-md-8">

			<table class="table table-striped">
				
				<tr>
					<th>first_name</th>
					<th>last_name</th>
					<th>email_id</th>
					<th>mobile_number</th>
					<th>birth_date</th>
					<th>experience</th>
					<th>education</th>
					
					
					<th width="60">Edit</th>
					<th width="100">Delete</th>	
				</tr>	
				<?php if(!empty($users))
				{
					foreach($users as $user){?>

				<tr>
					<td><?php echo  $user['first_name']?></td>
					<td><?php echo $user['last_name']?></td>
					<td><?php echo $user['email_id']?></td>
					<td><?php echo  $user['mobile_number']?></td>
					<td><?php echo $user['birth_date']?></td>
					<td><?php echo $user['experience']?></td>
					<td><?php echo  $user['education']?></td>
					
			    	
					<td><a href="<?php echo base_url().'index.php/user/edit/'.$user['id']?>" class="btn btn-primary">edit</a>
					</td>
					
					
					<td><a href="<?php echo base_url().'index.php/user/delete/'.$user['id']?>" class="btn btn-danger">delete</a>
					</td>
				</tr>
				<?php }}

				 else{ ?>
				<tr>
					<td colspan="5">Record Not Found</td>
				
				</tr>
				<?php }?>	

			</table>
		<div>	
	</div>	
</body>
</html>