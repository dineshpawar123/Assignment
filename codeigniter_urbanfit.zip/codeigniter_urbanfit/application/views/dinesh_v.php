<!DOCTYPE html>
<html>
<head>
<title>login page</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'?>">
</head>
<body>


<h2><center><font color="gray" size="20"><b>URBAN FIT</b></font></center></h2>

<br><br>

 
  <form  action="http://localhost/codeigniter_urbanfit/index.php/dinesh_c/process" method="post">
  	
	<center><font color="red" size="5"><?php echo isset($error) ? $error : '';?></font>
	<table border="20" color="green" cellpadding="10" cellspacing="10">
		<tr><td>
  		  <label for="uname"><b><font color="cyan" size="10"><b>Login to your account </b></font></label><br>
	     
	      <br><br>

	     
	  
	      </td></tr>
  		<tr><td>
  		  <label for="uname"<b><font color="red" size="5">Username</font></b></label>
	      <input type="text" placeholder="Enter Username" name="username" required>
	      <br><br>

	     
	  
	      </td></tr>
	      <tr><td>
	      <label for="psw"><b><font color="red" size="5">Password</font></b></label>
	      <input type="password" placeholder="Enter Password" name="password" required>
	      <br><br>
	  </td></tr> 
	      <tr><td>
	      <button type="submit">Login</button>
	      </td></tr>
  	
  	</table></center>
</body>
</html>