<!DOCTYPE html>
<html>
<head>
<title>crud application Update user</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'?>">

</head>	
<body>
	<div class="navbar navbar-dark bg-dark">
		<div class="container">
			<a href="#" class="navbar-brand">Create Nutritionist</a>
		</div>
	</div>

	<div class="container" style="padding-top :10px;">
		<h3>Update user</h3>
		<div class="col-md-12">
		        </div>
		<form  method="post" name="createuser" action="<?php echo base_url().'index.php/User/edit/'.$user['id'];?>">
			<div class="row">
			<form name="create user">
			<div class="col-md-3">
		      
				<div class="form-group">
					<label>First Name*</label>
					<input type="text" name="first_name" value="<?php echo set_value('first_name',$user['first_name']);?>" class="form-control">
					<?php echo form_error('name');?>
				</div>

				<div class="form-group">
					<label>Mobile Number*</label>
				    <input type="text" name="mobile_number" value="<?php echo set_value('mobile_number',$user['mobile_number']);?>" class="form-control">
					<?php echo form_error('mobile_number');?>
				</div>
				<div class="form-group">
					<label>Education*</label>
				    <input type="text" name="education" value="<?php echo set_value('education',$user['education']);?>" class="form-control">
					<?php echo form_error('education');?>
				</div>
				<div class="form-group">
					<label>Description*</label>
				    <input type="text" name="description" value="<?php echo set_value('description',$user['description']);?>" class="form-control">
					<?php echo form_error('description');?>
				</div>


			</div>
			<div class="col-md-3">
		      
				<div class="form-group">
					<label>Last Name*</label>
					<input type="text" name="last_name" value="<?php echo set_value('last_name',$user['last_name']);?>" class="form-control">
					<?php echo form_error('last_name');?>
				</div>

				<div class="form-group">
					<label>Birth Date*</label>
				    <input type="text" name="birth_date" value="<?php echo set_value('birth_date',$user['birth_date']);?>" class="form-control">
					<?php echo form_error('birth_date');?>
				</div>
				<div class="form-group">
					<label>Password*</label>
				    <input type="password" name="password" value="<?php echo set_value('password',$user['password']);?>" class="form-control">
					<?php echo form_error('password');?>
				</div>
			</div>
			<div class="col-md-3">
		      
				<div class="form-group">
					<label>Email Id*</label>
					<input type="text" name="email_id" value="<?php echo set_value('email_id',$user['email_id']);?>" class="form-control">
					<?php echo form_error('email_id');?>
				</div>

				<div class="form-group">
					<label>Experience*</label>
				    <input type="text" name="experience" value="<?php echo set_value('experience',$user['experience']);?>" class="form-control">
					<?php echo form_error('experience');?>
				</div>
				<div class="form-group">
					<label>Confirm Password*</label>
				    <input type="password" name="confirm_password" value="<?php echo set_value('experience',$user['confirm_password']);?>" class="form-control">
					<?php echo form_error('confirm_password');?>
				</div>

				<div class="form-group">
					<button class="btn btn-primary">update</button>
					
					<a href="<?php echo base_url().'index.php/user/index/';?>" class="btn-secondary btn">cancel</a>
				</div>
			</div>





			</div>	
		</form>
		</div>	
	</form>
</div>

	</div>	
</body>
</html>