<?php

class dinesh_c extends CI_Controller {

	function __construct()
    {
        // this is your constructor
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
    }

	public function index()
	{

		$this->load->view('dinesh_v');
		
	}

	public function logout()
	{

       $this->session->unset_userdata('username');
       redirect("dinesh_c");          
	}

	public function process()
	{

		$username=$this->input->post('username');
		$password=$this->input->post('password');


		if($username =='admin@admin' && $password =='123456'){
		
		$this->load->model('usermodel');
		$users=$this->usermodel->all();

		$data=array();
		
		$data['users']=$users;
		$this->load->view('list',$data);

			//$name = $_SESSION['username'];
		$this->session->set_userdata('some_name', $username);
		$this->session->set_userdata(array('username1'=>$username));
		$data['username12']=$username;
		//$this->load->view('list');
		
			//$this->load->view('dinesh_v1');
	
		}

		else{


			$data['error']='Account is invalid';
			$this->load->view('dinesh_v',$data);
		}
		
	}
}
