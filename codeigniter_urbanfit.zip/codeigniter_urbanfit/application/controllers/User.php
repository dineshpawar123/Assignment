<?php

class User extends CI_Controller {

	function index()
	{

		$this->load->model('usermodel');
		$users=$this->usermodel->all();

		$data=array();
		
		$data['users']=$users;
		$this->load->view('list',$data);

	}


	function create()
	{

		$this->load->model('usermodel');
		$this->form_validation->set_rules('first_name','Name','required');
		$this->form_validation->set_rules('last_name','Name','required');
		$this->form_validation->set_rules('email_id','Email','required|valid_email');
		$this->form_validation->set_rules('mobile_number','Mobile number','required');
		$this->form_validation->set_rules('birth_date','Birth_date','required');
		$this->form_validation->set_rules('experience','Experience','required');
		$this->form_validation->set_rules('education','Education','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('confirm_password','Correct Confirm_password','required');
		$this->form_validation->set_rules('description','Description','required');

		if($this->form_validation->run()==false)
		{
			
			$this->load->view('create');

		}		
		else
		{
				$formArray=array();
				$formArray['first_name']=$this->input->post('first_name');
				$formArray['last_name']=$this->input->post('last_name');
				$formArray['email_id']=$this->input->post('email_id');
				$formArray['mobile_number']=$this->input->post('mobile_number');
				$formArray['birth_date']=$this->input->post('birth_date');
				$formArray['experience']=$this->input->post('experience');
				$formArray['education']=$this->input->post('education');
				$formArray['password']=$this->input->post('password');
				$formArray['confirm_password']=$this->input->post('confirm_password');
				$formArray['description']=$this->input->post('description');
			
				$this->usermodel->create($formArray);
				$this->session->set_flashdata('success','Record added succesfully');////////////////////
				redirect(base_url().'index.php/user/index');
			    
			    
		}
	}



	function edit($userId)
	{

		$this->load->model('usermodel');
		$user=$this->usermodel->getUser($userId);
		$data=array();
		$data['user']=$user;
		
		
		$this->form_validation->set_rules('first_name','Name','required');
		$this->form_validation->set_rules('last_name','Name','required');
		$this->form_validation->set_rules('email_id','Email','required|valid_email');
		$this->form_validation->set_rules('mobile_number','Mobile number','required');
		$this->form_validation->set_rules('birth_date','Birth_date','required');
		$this->form_validation->set_rules('experience','Experience','required');
		$this->form_validation->set_rules('education','Education','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('confirm_password','Confirm_password','required');
		$this->form_validation->set_rules('description','Description','required');

		

		if(	$this->form_validation->run()==false)
		{
		$this->load->view('edit',$data);
		}
		else
		{
			$formArray=array();
			$formArray['first_name']=$this->input->post('first_name');
			$formArray['last_name']=$this->input->post('last_name');
			$formArray['email_id']=$this->input->post('email_id');
			$formArray['mobile_number']=$this->input->post('mobile_number');
			$formArray['birth_date']=$this->input->post('birth_date');
			$formArray['experience']=$this->input->post('experience');
			$formArray['education']=$this->input->post('education');
			$formArray['password']=$this->input->post('password');
			$formArray['confirm_password']=$this->input->post('confirm_password');
			$formArray['description']=$this->input->post('description');
			
			$this->usermodel->updateUser($userId,$formArray);	
		  	$this->session->set_flashdata('success','Record update succesfully');
		  	redirect(base_url().'index.php/user/index/');
		}
	}



	function delete($userId)
	{	
		$this->load->model('Usermodel');
		$user=$this->Usermodel->getuser($userId);//delete from user where user_id = ?;
		if(empty($user))
		{
			$this->session->set_flashdata('failure','Record not found in database ');
		  	redirect(base_url().'index.php/user/index');

		}
		else
		{

			$this->Usermodel->deleteUser($userId);

			$this->session->set_flashdata('success','Record deleted successfully ');
		  	redirect(base_url().'index.php/user/index');

		}
	}


}



?>