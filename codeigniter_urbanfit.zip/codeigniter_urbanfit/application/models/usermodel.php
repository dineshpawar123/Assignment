<?php

class usermodel extends CI_model {

	
	 function create($formArray)
	{
		$this->db->insert('table_nutritionist',$formArray);//insert into users(name,valu)
	}
	
	function all()
	{
		return $users=$this->db->get('table_nutritionist')->result_array(); //select * from users
	}

	function getUser($userId)
	{
		$this->db->where('id',$userId);

		return	$user=$this->db->get('table_nutritionist')->row_array();// select * from user where u_id=? ;

	}

	function updateUser($userId,$formArray)
	{
		$this->db->where('id',$userId);
		$this->db->update('table_nutritionist',$formArray); //update users SET name=?,email=? where user_id=?;

	}

	function deleteuser($userId)
	{	
		$this->db->where('id',$userId);
		$this->db->delete('table_nutritionist');//delete from user where user_id = ?;
	}

}


